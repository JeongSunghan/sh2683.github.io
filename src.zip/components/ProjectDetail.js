import React from 'react';
import { useParams } from 'react-router-dom';
import { Box, Typography, List, ListItem } from '@mui/material';

const projects = [
    { id: 1, title: 'Mini Project', description: '스키장비 및 경매 웹', techStack: ['HTML', 'CSS', 'JavaScript', 'React'] },
    { id: 2, title: 'Advanced Project', description: '맛집 사이트', techStack: ['Java', 'Spring Boot', 'MySQL'] },
    { id: 3, title: 'Final Project', description: 'To Do List 웹 애플리케이션', techStack: ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js'] },
];

const ProjectDetail = () => {
    const { id } = useParams();
    const project = projects.find(proj => proj.id === parseInt(id));

    if (!project) {
        return <Typography variant="h4">Project not found</Typography>;
    }

    return (
        <Box p={4} bgcolor="black" color="white" minHeight="100vh">
            <Typography variant="h3" gutterBottom>
                {project.title}
            </Typography>
            <Typography variant="h5" gutterBottom>
                {project.description}
            </Typography>
            <Typography variant="h6">Tech Stack:</Typography>
            <List>
                {project.techStack.map((tech, index) => (
                    <ListItem key={index}>{tech}</ListItem>
                ))}
            </List>
        </Box>
    );
};

export default ProjectDetail;
