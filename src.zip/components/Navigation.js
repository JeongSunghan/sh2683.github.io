import React from 'react';
import { Box, IconButton } from '@mui/material';
import { Home, Person, List, GitHub } from '@mui/icons-material';
import { Link as ScrollLink } from 'react-scroll';
import { Link as RouterLink } from 'react-router-dom';

const Navigation = () => {
  return (
    <Box
      position="fixed"
      left={0}
      top="50%"
      transform="translateY(-50%)"
      display="flex"
      flexDirection="column"
      bgcolor="black"
      p={1}
    >
      <ScrollLink to="home" smooth duration={500}>
        <IconButton sx={{ color: 'white' }}>
          <Home />
        </IconButton>
      </ScrollLink>

      <ScrollLink to="about" smooth duration={500}>
        <IconButton sx={{ color: 'white' }}>
          <Person />
        </IconButton>
      </ScrollLink>
      <ScrollLink to="projects" smooth duration={500}>
        <IconButton sx={{ color: 'white' }}>
          <List />
        </IconButton>
      </ScrollLink>

      <IconButton href="https://github.com/JeongSunghan" sx={{ color: 'white' }}>
        <GitHub />
      </IconButton>
    </Box>
  );
};

export default Navigation;
