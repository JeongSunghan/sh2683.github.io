import React from 'react';
import { Box, Typography, Grid, Card, CardContent } from '@mui/material';
import { Link } from 'react-router-dom';

const projects = [
  { id: 1, title: 'Mini Project', description: '스키장비 및 경매 웹', techStack: ['HTML', 'CSS', 'JavaScript', 'React'] },
  { id: 2, title: 'Advanced Project', description: '맛집 사이트', techStack: ['Java', 'Spring Boot', 'MySQL'] },
  { id: 3, title: 'Final Project', description: 'To Do List 웹 애플리케이션', techStack: ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js'] },
];

const Projects = () => {
  return (
    <Box display="flex" alignItems="center" className="full-height" bgcolor="black" color="white" id="projects">
      <Box flex={1} display="flex" justifyContent="center" alignItems="center">
        <Typography variant="h2" component="h2" gutterBottom>
          Projects
        </Typography>
      </Box>
      <Box flex={2} textAlign="left" p={4}>
        <Grid container spacing={2}>
          {projects.map(project => (
            <Grid item xs={12} sm={6} md={4} key={project.id}>
              <Link to={`/project/${project.id}`} style={{ textDecoration: 'none' }}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" component="h3">
                      {project.title}
                    </Typography>
                    <Typography color="textSecondary">
                      {project.description}
                    </Typography>
                  </CardContent>
                </Card>
              </Link>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  );
};

export default Projects;
